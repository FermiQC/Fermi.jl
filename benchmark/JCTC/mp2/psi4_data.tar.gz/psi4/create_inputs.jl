temp = """
import psi4

# Basic options trying to be uniform

psi4.set_num_threads(10)
psi4.set_memory('100 GB')
psi4.set_options({"basis" : "cc-pvtz",
                  "scf_type" : "df",
                  "mp2_type" : "df",
                  "df_basis_scf" : "cc-pvtz-jkfit",
                  "df_basis_mp2" : "cc-pvtz-ri",
                  "puream" : True,
                  "e_convergence" : 1e-8,
                  "d_convergence" : 1e-8})

molecule {
[molecule]
symmetry c1
}

energy("mp2")
"""

for i = 1:22
    xyz = readlines("../../xyz/S22-$i-dimer.xyz")[3:end]
    xyz = join(xyz, "\n")

    mkdir("S$i")
    open("S$i/input.dat", "w") do io
        write(io, replace(temp, "[molecule]"=>xyz))
    end
end
