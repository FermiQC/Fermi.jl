using Fermi
using Fermi.Integrals
using MKL

# Cold run
@set printstyle none
@set df true
@energy ccsd(t)
@set pt_alg 2
@energy ccsd(t)


# Basic options trying to be uniform

Fermi.set_num_threads()

@set {
    basis cc-pvdz
    rifit cc-pvtz-rifit
    jkfit cc-pvtz-jkfit
    scf_e_conv 1e-8
    scf_max_rms 1e-8
    cc_e_conv 1e-5
    cc_max_rms 1e-5
    printstyle file
    output output.dat
}

for i in 1:22

    # Read in xyz file
    molstring = read("../../xyz/S22-$(i)-dimer.xyz", String)

    # Remove first two lines from xyz
    molstring = String(split(molstring, "\n",limit=3)[end])
    Fermi.Options.set("molstring", molstring)
    @freezecore


    # Compute SCF
    wfn = @energy rhf

    # Get MO Integral helper
    moints = IntegralHelper(orbitals=wfn.orbitals, eri_type=RIFIT())

    cc = @energy moints => ccsd

    @set pt_alg 1
    # Time integral transformation
    timings = zeros(10)
    output("Timing Alg 1")
    for n = 1:10
        t = @elapsed @energy cc, moints => ccsd(t)
        timings[n] = t
        output("S$i - (T) alg 1 $n run: $t")
    end
    output("@@ Average time for (T) alg 1: {:15.10f}", sum(timings)/10)
    

    @set pt_alg 2
    # Time energy computation
    timings = zeros(10)
    output("Timing Alg 2")
    for n = 1:10
        t = @elapsed @energy cc, moints => ccsd(t)
        timings[n] = t
        output("S$i - (T) alg 2 $n run: $t")
    end
    output("@@ Average time for (T) alg 2: {:15.10f}", sum(timings)/10)

    GC.gc()
end



    

    
